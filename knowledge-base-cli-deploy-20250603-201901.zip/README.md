# Knowledge Base CLI - Deployment Package

## Quick Start

1. Instale Python 3.8+ se necessário
2. Execute o sistema:
   ```bash
   python cli.py
   ```

## Comandos Básicos

- `search ID-000001` - Busca por ID específico
- `range ID-000001 ID-000020` - Busca por intervalo  
- `books termo` - Busca nos livros
- `help` - Ajuda completa

## Arquivos Incluídos

- `cli.py` - Interface principal
- `knowledge_base.py` - Engine de busca
- `fictional_books.txt` - Dados estruturados
- `books/` - Biblioteca de livros
- `requirements.txt` - Dependências (opcional)

## Características

- ✅ Busca binária O(log n)
- ✅ 19 livros incluídos
- ✅ Sem dependências externas
- ✅ Interface CLI intuitiva

## Repositório Original

https://github.com/moroni646/ct-coding-tank-ada-team-4

Gerado em: 2025-06-03 20:19:04
